UnitTypes.latum.hidden = false
UnitTypes.renale.hidden = false